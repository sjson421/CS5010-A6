import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

/**
 * Tests K-means clustering algorithm model.
 */

public class KMeansClusteringTest {
  @Before
  public void setUp() {

  }

  @Test
  public void test() {

  }
}
